# SearchHorizonBench

**A Benchmark for Search Value in AI Agents**

Evaluate what another search contributes to an answer. This offline artifact
contains saved public inputs, repeated action outcomes, frozen baseline
predictions, and scorers for success probabilities, marginal gains, and
cost-sensitive decisions.

## Quick start

Use Python 3.10 or newer. From this directory run:

```bash
python -m pip install -r requirements.txt
python scripts/replay_examples.py
```

The replay uses saved records and NumPy. It makes no model or search API calls.
It checks three examples against `examples/expected_replay.json` and writes
their scores to `results/`.

| Example | Expected value |
| --- | --- |
| Test-1632 calibrated action-success Brier | 0.1796987195 |
| Test-1632 generation-noise-corrected gain MSE | 0.0458585746 |
| Test-1632 priced calibrated-policy utility | 0.6665569409 |
| Collection-96 calibrated gain MSE | 0.0264415565 |

The first two quantities use reference-equivalent correctness and equal mass
for each of five task strata. Policy utility charges prediction and actor API
tokens at 0.005 reward units per thousand tokens. The collection example uses
bounded set F1 and a distinct 96-task evaluation population.

## Evaluate a new forecaster

Read only each record's `input` object in
`data/forecast_benchmark/cost_confirmation/semantic_flash_v1_inputs.jsonl`.
Use `unit_id` to join your predictions to the evaluator. Write one JSON object
per line:

```json
{"unit_id":"<unchanged unit_id>","status":"ok","delta":0.1,"p_reuse_correct":0.5,"p_new_correct":0.6,"inference_API_tokens":128}
```

`delta` is expected SEARCH reward minus expected THINK reward. The action
probabilities lie in [0, 1], and their difference gives the gain forecast.
The API-token field records the actual cost of obtaining the prediction.

```bash
python scripts/score_value_forecasts.py \
  --draws data/forecast_benchmark/cost_confirmation/semantic_flash_v1_draws.jsonl \
  --predictions my_predictions.jsonl --actor-model deepseek-flash \
  --baseline data/forecast_benchmark/cost_confirmation/source120_baseline.json \
  --weighting equal_strata --output results/my_value_scores.json

python scripts/score_search_policy.py \
  --draws data/forecast_benchmark/cost_confirmation/semantic_flash_v1_draws.jsonl \
  --predictions my_predictions.jsonl --actor-model deepseek-flash \
  --mean-extra-tokens 7007.49375 --penalty 0.005 \
  --weighting equal_strata --output results/my_policy_scores.json
```

For collection tasks, write `task_id`, `kind` and a three-element `values`
array in the action order stored in each outcome record. Choose
`kind="expected_rewards"` for expected bounded F1, or
`kind="relative_gains"` for gains relative to the first action. Run:

```bash
python scripts/score_collection_forecasts.py \
  --draws data/forecast_benchmark/collection_value/test_draws.jsonl \
  --predictions my_collection_predictions.jsonl \
  --output results/my_collection_scores.json
```

## Information boundary

Public history is the predictor input. Outcome draws, reference answers,
support components, task strata, evaluation resources, and selection flags
belong to the evaluator. Development records support fitting; freeze a new
predictor before reading its test outcomes. This fully disclosed offline
artifact supports reproducible comparisons. A new prospective claim requires
an independent evaluation cohort.

The record keys `reuse` and `new` denote THINK and SEARCH in the binary track.
Repeated answer strings share reward-case identities. Unknown semantic labels
retain their common-case assignments in risk bounds. Each endpoint retains
its own scoring rule. Transport-incomplete predictions require repair before
scoring.

## Artifact contents

`data/forecast_benchmark/` contains the exported scoring records and their
original metadata. `manifest.json` lists every exported file, row count and
byte size. Several endpoint files score the same executions; their row counts
must be interpreted separately. Historical run references in metadata
identify provenance outside this compact artifact.

The complete study reports 45,632 distinct actor executions, 8,880 forecasts
and 3,168 questions. This download is the exported offline scoring artifact.
Full raw provider request logs, search caches, trained models and the private
research workspace are outside this artifact.

See `DATA_CARD.md` for population and metric definitions and `ATTRIBUTION.md`
for original dataset and corpus sources. `CITATION.bib` provides the manuscript
citation without assigning a publication identifier.
